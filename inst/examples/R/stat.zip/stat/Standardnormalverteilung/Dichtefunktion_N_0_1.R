curve(from=-4, to=4, dnorm(x, mean=0, sd=1), ylab="f(z)", main="Dichtefunktion der N(0;1)", xlab="z", col="red", ylim=c(0.00,0.4), lty=1, lwd=4, font.lab=2, "xaxs"="i" ,"yaxs"="i", bty="l")
