curve(from=-4, to=4, pnorm(x, mean=0, sd=1), main="Verteilungsfunktion der N(0;1)", ylab="F(z)", xlab="z", col="red", ylim=c(0.00,1.0), lty=1, lwd=4, font.lab=2, "xaxs"="i" ,"yaxs"="i", bty="l")
