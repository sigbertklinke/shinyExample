curve(from=-2, to=6, dnorm(x, mean=2, sd=1), ylab="f(x)", col="darkgreen", main="Dichtefunktion der N(2; 1)", ylim=c(0.00,0.4), lty=1, lwd=4, font.lab=2, "xaxs"="i" ,"yaxs"="i", bty="l")
