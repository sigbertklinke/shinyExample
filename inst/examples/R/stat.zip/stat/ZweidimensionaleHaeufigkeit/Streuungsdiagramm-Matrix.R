attach(mtcars)
pairs(~wt+mpg+disp,data=mtcars, col="black", labels=NA)