cat("Spearman'scher Rangkorrelationskoeffizient: 0.6617
        \nKendall'scher Rangkorrelationskoeffizient: 0.4526
    \n[1] konkordante Paare: 138
    \n[2] diskordante Paare: 52
    \n[3] gleich nur bzgl. x: 0
    \n[4] gleich nur bzgl. y: 0
    \n[5] gleich bzgl. x und y: 0
    ")

